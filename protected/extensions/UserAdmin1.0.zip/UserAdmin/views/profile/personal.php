<h4 class='centered'>You can change your password (or other allowed fields here)</h4>

<div class='alert alert-info centered'>
        User login: <?php echo $user->login; ?>
</div>
