<!DOCTYPE HTML>
<html>
<head>
        <meta http-equiv="Content-type" content="text/html; charset=utf-8"/>
        <meta name="robots" content="noindex, nofollow">

        <title><?php echo Yii::t("UserAdminModule.front","Login"); ?></title>
</head>
<body>
        <?php echo $content; ?>
</body>
</html>
